export const jwtConstants = {
  secret: 'secretKey',
  TOKEN_DURATION: '36000',
};
